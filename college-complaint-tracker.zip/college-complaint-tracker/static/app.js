document.querySelectorAll('.alert').forEach((alert) => {
  setTimeout(() => { alert.style.opacity = '0'; setTimeout(() => alert.remove(), 300); }, 4000);
});

const flipCard = document.querySelector('#flipCard');
if (flipCard) {
  if (window.location.pathname.endsWith('/register')) flipCard.classList.add('is-flipped');
  document.querySelectorAll('[data-flip]').forEach((button) => button.addEventListener('click', (event) => {
    event.preventDefault();
    const showSignUp = button.dataset.flip === 'signup';
    flipCard.classList.toggle('is-flipped', showSignUp);
  }));
}

document.querySelectorAll('.password-toggle').forEach((button) => button.addEventListener('click', () => {
  const input = button.parentElement.querySelector('input');
  const isHidden = input.type === 'password';
  input.type = isHidden ? 'text' : 'password';
  button.textContent = isHidden ? 'Hide' : 'Show';
}));

const newPassword = document.querySelector('.new-password');
if (newPassword) newPassword.addEventListener('input', () => {
  const hint = newPassword.closest('label').querySelector('.password-hint');
  const length = newPassword.value.length;
  hint.textContent = length < 6 ? 'Use at least 6 characters.' : length < 10 ? 'Good password length.' : 'Strong password length.';
  hint.className = `password-hint ${length >= 6 ? 'valid' : ''}`;
});

const description = document.querySelector('#description');
if (description) {
  const counter = document.querySelector('#characterCount');
  const updateCounter = () => counter.textContent = `${description.value.length} / 1000 characters`;
  description.addEventListener('input', updateCounter); updateCounter();
}

const priority = document.querySelector('#prioritySelect');
if (priority) priority.addEventListener('change', () => {
  const tips = { Low: 'Low: minor issue; can be handled later.', Medium: 'Medium: needs normal attention.', High: 'High: choose only for urgent safety or service issues.' };
  const tip = document.querySelector('#priorityTip');
  tip.textContent = tips[priority.value]; tip.className = priority.value === 'High' ? 'high-tip' : '';
});

document.querySelectorAll('form[action*="/update"]').forEach((form) => form.addEventListener('submit', (event) => {
  if (!window.confirm('Save this complaint status update?')) event.preventDefault();
}));

// Small visual transition for sign-in and sign-out actions.
const transitionScreen = document.querySelector('#transitionScreen');
const transitionText = document.querySelector('#transitionText');
const showTransition = (text) => {
  if (!transitionScreen) return;
  transitionText.textContent = text;
  transitionScreen.classList.add('show');
};

document.querySelectorAll('.login-face form, .signup-face form').forEach((form) => {
  form.addEventListener('submit', () => showTransition(form.action.includes('/register') ? 'Creating your account...' : 'Signing you in...'));
});

document.querySelector('.logout')?.addEventListener('click', (event) => {
  event.preventDefault();
  const logoutUrl = event.currentTarget.href;
  showTransition('Signing you out...');
  setTimeout(() => { window.location.href = logoutUrl; }, 550);
});
