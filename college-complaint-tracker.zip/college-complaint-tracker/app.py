import os
from datetime import datetime
from functools import wraps

import mysql.connector  #mysql connector to connect the application to the database
from flask import Flask, flash, redirect, render_template, request, session, url_for  #importing the flask
from werkzeug.security import check_password_hash, generate_password_hash  #essential library to for password security and checking

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-secret-key-before-deployment"

# Change these values to match your local MySQL installation.
DB_CONFIG = {   #keep this info secret and do not share it with anyone beacuse it contains sensitive information about the database connection about database like username and password
    "host": "localhost",
    "user": "root",
    "password": "nilesh005",
    "database": "college_complaint_tracker",
}

#database(mysql) connector to store data in database
def get_db():
    return mysql.connector.connect(**DB_CONFIG)


def login_required(view): #login function
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view): 
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Admin access is required.", "danger")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped


@app.route("/")
def index(): 
    return redirect(url_for("dashboard" if "user_id" in session else "login"))


@app.route("/register", methods=["GET", "POST"])  #getting the sign-up details from user and storing it in the database
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        department = request.form.get("department", "").strip()
        password = request.form.get("password", "")
        if not all([name, email, department, password]):
            flash("Please fill in every field.", "danger")
            return render_template("register.html")
        db = get_db()
        cursor = db.cursor()
        try:                              #inserting data in the database using exception handling to avoid duplicate email registration
            cursor.execute(
                "INSERT INTO users (name, email, department, password_hash, role) VALUES (%s, %s, %s, %s, 'student')",
                (name, email, department, generate_password_hash(password)),
            )
            db.commit()
            flash("Account created. Please log in.", "success")
            return redirect(url_for("login"))
        except mysql.connector.IntegrityError:
            flash("That email is already registered.", "danger")
        finally:
            cursor.close()
            db.close()
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():     #login function for user authentication
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        db = get_db()
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()
        db.close()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session.update(user_id=user["id"], name=user["name"], role=user["role"])
            flash(f"Welcome back, {user['name']}!", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():  #user logout function to clear the session and redirect to login page
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():  #dashboard function to show the dashboard of the user and admin with different views
    db = get_db()
    cursor = db.cursor(dictionary=True)
    if session["role"] == "admin":
        cursor.execute("SELECT status, COUNT(*) AS total FROM complaints GROUP BY status")
        counts = {row["status"]: row["total"] for row in cursor.fetchall()}
        cursor.execute("""SELECT c.*, u.name AS student_name, u.department
                          FROM complaints c JOIN users u ON c.user_id = u.id
                          ORDER BY c.created_at DESC LIMIT 8""")
        complaints = cursor.fetchall()
        cursor.close(); db.close()
        return render_template("admin_dashboard.html", complaints=complaints, counts=counts)
    cursor.execute("SELECT * FROM complaints WHERE user_id = %s ORDER BY created_at DESC", (session["user_id"],))
    complaints = cursor.fetchall()
    cursor.close(); db.close()
    return render_template("student_dashboard.html", complaints=complaints)


@app.route("/complaints/new", methods=["GET", "POST"])
@login_required
def new_complaint(): #new complaint fucntion to raise a new complaint by the user and store it in the database
    if request.method == "POST":
        category = request.form.get("category", "")
        subject = request.form.get("subject", "").strip()
        description = request.form.get("description", "").strip()
        location = request.form.get("location", "").strip()
        priority = request.form.get("priority", "Medium")
        if not all([category, subject, description, location]):
            flash("Please complete all complaint details.", "danger")
            return render_template("new_complaint.html")
        db = get_db(); cursor = db.cursor()
        cursor.execute("""INSERT INTO complaints (user_id, category, subject, description, location, priority)
                          VALUES (%s, %s, %s, %s, %s, %s)""",
                       (session["user_id"], category, subject, description, location, priority))
        db.commit(); cursor.close(); db.close()
        flash("Complaint submitted successfully.", "success")
        return redirect(url_for("dashboard"))
    return render_template("new_complaint.html")


@app.route("/complaints/<int:complaint_id>")
@login_required
def complaint_detail(complaint_id): #complaint detail function to show the details of the complaint raised by the user or admin
    db = get_db(); cursor = db.cursor(dictionary=True)
    cursor.execute("""SELECT c.*, u.name AS student_name, u.email, u.department
                      FROM complaints c JOIN users u ON c.user_id = u.id WHERE c.id = %s""", (complaint_id,))
    complaint = cursor.fetchone()
    if not complaint or (session["role"] != "admin" and complaint["user_id"] != session["user_id"]):
        cursor.close(); db.close()
        flash("Complaint not found.", "danger")
        return redirect(url_for("dashboard"))
    cursor.execute("SELECT * FROM complaint_updates WHERE complaint_id = %s ORDER BY created_at DESC", (complaint_id,))
    updates = cursor.fetchall()
    cursor.close(); db.close()
    return render_template("complaint_detail.html", complaint=complaint, updates=updates)


@app.route("/complaints/<int:complaint_id>/update", methods=["POST"])
@login_required
@admin_required
def update_complaint(complaint_id): #update complaint function like in progress or rejected or anything-else by the admin and store it in the database
    status = request.form.get("status", "Pending")
    note = request.form.get("note", "").strip()
    db = get_db(); cursor = db.cursor()
    cursor.execute("UPDATE complaints SET status = %s, updated_at = %s WHERE id = %s", (status, datetime.now(), complaint_id))
    if note:
        cursor.execute("INSERT INTO complaint_updates (complaint_id, note, status) VALUES (%s, %s, %s)", (complaint_id, note, status))
    db.commit(); cursor.close(); db.close()
    flash("Complaint updated.", "success")
    return redirect(url_for("dashboard"))


@app.route("/complaints")
@login_required
@admin_required
def all_complaints():  #all complaint function to show all the issues raised by the users and their status
    status = request.args.get("status", "")
    db = get_db(); cursor = db.cursor(dictionary=True)
    query = "SELECT c.*, u.name AS student_name, u.department FROM complaints c JOIN users u ON c.user_id = u.id"
    params = ()
    if status:
        query += " WHERE c.status = %s"; params = (status,)
    cursor.execute(query + " ORDER BY c.created_at DESC", params)
    complaints = cursor.fetchall()
    cursor.close(); db.close()
    return render_template("all_complaints.html", complaints=complaints, selected_status=status)


if __name__ == "__main__":
    app.run(debug=True)
