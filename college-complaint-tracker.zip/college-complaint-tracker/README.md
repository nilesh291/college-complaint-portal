# College Complaint & Issue Tracking System

A BCA mini project made with HTML, CSS, JavaScript, Python (Flask), and **MySQL only**.

## Features

- Student registration and login
- Submit and track complaints
- Complaint category, location, priority, and status
- Admin dashboard with summary counts
- Admin updates with status notes
- Student/admin role access

## Setup

1. Create the database by running `database.sql` in MySQL Workbench or phpMyAdmin.
2. In `app.py`, replace `YOUR_MYSQL_PASSWORD` with your MySQL password.
3. In the project folder, install packages: `pip install -r requirements.txt`
4. Start the application: `python app.py`
5. Open `http://127.0.0.1:5000` in a browser.
6. Register a user, then make it an admin in MySQL using the commented query at the end of `database.sql`.

## Suggested demo flow

Register one student and one admin. Log in as the student to submit a complaint. Log in as the admin, update it to **In Progress** and then **Resolved**, adding a note each time. Finally, sign in as the student and show the complaint history.
