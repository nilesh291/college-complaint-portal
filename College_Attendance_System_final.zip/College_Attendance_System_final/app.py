from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from mysql.connector import Error
from functools import wraps

app = Flask(__name__)
app.secret_key = "college_attendance_secret_key"


# ---------------- DATABASE CONNECTION ----------------
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="nilesh005",
        database="college_attendance"
    )


# ---------------- LOGIN REQUIRED ----------------
def login_required(role=None):
    def decorator(view):
        @wraps(view)
        def wrapped_view(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))

            if role and session.get("role") != role:
                flash("You are not allowed to access this page.", "danger")
                return redirect(url_for("login"))

            return view(*args, **kwargs)
        return wrapped_view
    return decorator


# ---------------- HOME ----------------
@app.route("/")
def home():
    if session.get("role") == "teacher":
        return redirect(url_for("teacher_dashboard"))
    if session.get("role") == "student":
        return redirect(url_for("student_dashboard"))
    return redirect(url_for("login"))


# ---------------- LOGIN ----------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip()
        password = request.form["password"]
        role = request.form["role"]

        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        if role == "teacher":
            cursor.execute(
                "SELECT * FROM teachers WHERE email=%s AND password=%s",
                (email, password)
            )
        else:
            cursor.execute(
                "SELECT * FROM students WHERE email=%s AND password=%s",
                (email, password)
            )

        user = cursor.fetchone()
        cursor.close()
        connection.close()

        if user:
            session["user_id"] = user["teacher_id"] if role == "teacher" else user["student_id"]
            session["name"] = user["name"]
            session["role"] = role

            if role == "teacher":
                return redirect(url_for("teacher_dashboard"))
            return redirect(url_for("student_dashboard"))

        flash("Invalid email, password, or role.", "danger")

    return render_template("login.html")


# ---------------- LOGOUT ----------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------- TEACHER DASHBOARD ----------------
@app.route("/teacher/dashboard")
@login_required("teacher")
def teacher_dashboard():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    teacher_id = session["user_id"]

    cursor.execute(
        "SELECT COUNT(*) AS total FROM subjects WHERE teacher_id=%s",
        (teacher_id,)
    )
    total_subjects = cursor.fetchone()["total"]

    cursor.execute("""
        SELECT COUNT(DISTINCT date) AS total
        FROM attendance a
        JOIN subjects s ON a.subject_id = s.subject_id
        WHERE s.teacher_id=%s
    """, (teacher_id,))
    total_days = cursor.fetchone()["total"]

    cursor.close()
    connection.close()

    return render_template(
        "teacher_dashboard.html",
        total_subjects=total_subjects,
        total_days=total_days
    )


# ---------------- MARK ATTENDANCE ----------------
@app.route("/teacher/attendance", methods=["GET", "POST"])
@login_required("teacher")
def mark_attendance():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    teacher_id = session["user_id"]

    cursor.execute(
        "SELECT * FROM subjects WHERE teacher_id=%s ORDER BY subject_name",
        (teacher_id,)
    )
    subjects = cursor.fetchall()

    selected_subject = request.args.get("subject_id", "")
    selected_date = request.args.get("date", "")

    students = []

    if selected_subject and selected_date:
        cursor.execute("""
            SELECT st.student_id, st.roll_no, st.name,
                   COALESCE(a.status, 'Present') AS status
            FROM students st
            LEFT JOIN attendance a
              ON st.student_id = a.student_id
             AND a.subject_id = %s
             AND a.date = %s
            ORDER BY st.roll_no
        """, (selected_subject, selected_date))
        students = cursor.fetchall()

    if request.method == "POST":
        subject_id = request.form["subject_id"]
        attendance_date = request.form["attendance_date"]

        cursor.execute(
            "SELECT subject_id FROM subjects WHERE subject_id=%s AND teacher_id=%s",
            (subject_id, teacher_id)
        )
        allowed_subject = cursor.fetchone()

        if not allowed_subject:
            flash("Invalid subject.", "danger")
            cursor.close()
            connection.close()
            return redirect(url_for("mark_attendance"))

        cursor.execute("SELECT student_id FROM students")
        all_students = cursor.fetchall()

        for student in all_students:
            student_id = student["student_id"]
            status = request.form.get(f"status_{student_id}", "Absent")

            cursor.execute("""
                INSERT INTO attendance (student_id, subject_id, date, status)
                VALUES (%s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE status=%s
            """, (
                student_id, subject_id, attendance_date, status, status
            ))

        connection.commit()
        flash("Attendance saved successfully!", "success")
        cursor.close()
        connection.close()

        return redirect(url_for(
            "mark_attendance",
            subject_id=subject_id,
            date=attendance_date
        ))

    cursor.close()
    connection.close()

    return render_template(
        "mark_attendance.html",
        subjects=subjects,
        students=students,
        selected_subject=selected_subject,
        selected_date=selected_date
    )


# ---------------- STUDENT DASHBOARD ----------------
@app.route("/student/dashboard")
@login_required("student")
def student_dashboard():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    student_id = session["user_id"]

    cursor.execute("""
        SELECT COUNT(*) AS total,
               COALESCE(SUM(status='Present'), 0) AS present,
               COALESCE(SUM(status='Absent'), 0) AS absent
        FROM attendance
        WHERE student_id=%s
    """, (student_id,))
    summary = cursor.fetchone()

    total = summary["total"]
    present = summary["present"]
    absent = summary["absent"]
    percentage = round((present / total) * 100, 2) if total else 0

    cursor.execute("""
        SELECT a.date, s.subject_name, a.status
        FROM attendance a
        JOIN subjects s ON a.subject_id = s.subject_id
        WHERE a.student_id=%s
        ORDER BY a.date DESC, s.subject_name
    """, (student_id,))
    records = cursor.fetchall()

    cursor.execute("""
        SELECT s.subject_name,
               COUNT(a.attendance_id) AS total,
               COALESCE(SUM(a.status='Present'), 0) AS present,
               COALESCE(SUM(a.status='Absent'), 0) AS absent
        FROM subjects s
        LEFT JOIN attendance a
          ON s.subject_id = a.subject_id
         AND a.student_id = %s
        GROUP BY s.subject_id, s.subject_name
        ORDER BY s.subject_name
    """, (student_id,))
    subject_summary = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template(
        "student_dashboard.html",
        total=total,
        present=present,
        absent=absent,
        percentage=percentage,
        records=records,
        subject_summary=subject_summary
    )


if __name__ == "__main__":
    app.run(debug=True)
