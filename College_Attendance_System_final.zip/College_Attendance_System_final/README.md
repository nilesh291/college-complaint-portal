# College Attendance Management System

A beginner-friendly BCA mini project using:

- Python
- Flask
- MySQL
- HTML
- CSS

## Features

### Teacher
- Teacher login
- View dashboard
- Select subject and date
- Mark Present/Absent
- Save or update attendance

### Student
- Student login
- View overall attendance percentage
- View total/present/absent classes
- View subject-wise attendance
- View day-wise attendance

## Setup

### 1. Install Python

Make sure Python is installed.

### 2. Install packages

Open terminal inside this project folder:

```bash
pip install -r requirements.txt
```

### 3. Create MySQL database

Open MySQL Workbench.

Open:

`database/attendance.sql`

Run the complete SQL script.

### 4. Change MySQL password

Open `app.py`.

Find:

```python
password="YOUR_MYSQL_PASSWORD"
```

Replace it with your MySQL root password.

Example:

```python
password="root123"
```

If your MySQL has no password, use:

```python
password=""
```

### 5. Start the project

Run:

```bash
python app.py
```

You should see:

```text
Running on http://127.0.0.1:5000
```

Open that address in your browser.

## Demo Login

Teacher:

Email: `teacher@college.com`

Password: `teacher123`

Student:

Email: `rahul@college.com`

Password: `student123`

Other students:

- priya@college.com / student123
- aman@college.com / student123
- neha@college.com / student123
- riya@college.com / student123

## Project Flow

Teacher logs in
→ selects subject
→ selects date
→ marks attendance
→ data is stored in MySQL
→ student logs in
→ student sees attendance percentage and records.

## Important

This project uses simple plain-text demo passwords to keep the BCA project easy to understand. For a real production application, passwords should be securely hashed.
