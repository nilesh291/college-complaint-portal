CREATE DATABASE IF NOT EXISTS college_attendance;
USE college_attendance;

CREATE TABLE IF NOT EXISTS teachers (
    teacher_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    roll_no VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    class_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS subjects (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_name VARCHAR(100) NOT NULL,
    teacher_id INT NOT NULL,
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id)
);

CREATE TABLE IF NOT EXISTS attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    date DATE NOT NULL,
    status ENUM('Present', 'Absent') NOT NULL,
    UNIQUE KEY unique_attendance (student_id, subject_id, date),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id)
);

INSERT IGNORE INTO teachers (teacher_id, name, email, password)
VALUES (1, 'Demo Teacher', 'teacher@college.com', 'teacher123');

INSERT IGNORE INTO students (student_id, roll_no, name, class_name, email, password)
VALUES
(1, '101', 'Rahul Sharma', 'BCA - K', 'rahul@college.com', 'student123'),
(2, '102', 'Priya Mehta', 'BCA - K', 'priya@college.com', 'student123'),
(3, '103', 'Aman Singh', 'BCA - K', 'aman@college.com', 'student123'),
(4, '104', 'Neha Joshi', 'BCA - K', 'neha@college.com', 'student123'),
(5, '105', 'Riya Jain', 'BCA - K', 'riya@college.com', 'student123');

INSERT IGNORE INTO subjects (subject_id, subject_name, teacher_id)
VALUES
(1, 'Python', 1),
(2, 'Advanced Java', 1),
(3, 'Digital Marketing', 1),
(4, 'Database Management System', 1);
